import datetime
import os
import time
import webbrowser
import sys
import pyautogui
import pyttsx3
import speech_recognition as sr
def initialize_engine():
    engine=pyttsx3.init("sapi5")
    voices=engine.getProperty("voices")
    engine.setProperty('voice',voices[1].id)
    rate=engine.getProperty('rate')
    engine.setProperty('rate',rate-50)
    volume=engine.getProperty('volume')
    engine.setProperty('volume',volume+0.25)
    return engine
def speak(text):
    engine=initialize_engine()
    engine.say(text)
    engine.runAndWait()

def command():
    r=sr.Recognizer()
    with sr.Microphone() as source:
        r.adjust_for_ambient_noise(source,duration=0.5)
        print("Listening..",end="",flush=True)
        r.pause_threshold=1.0
        r.phrase_threshold=0.3
        r.sample_rate=48000
        r.dynamic_energy_threshold=True
        r.operation_timeout=5
        r.non_speaking_duration=0.5
        r.dynamic_energy_adjustment=2
        r.energy_threshold=4000
        r.phrase_time_limit=10
        print(sr.Microphone.list_microphone_names())
        audio=r.listen(source)

    try:
        print("\r",end="", flush=True)
        print("Recognizing..",end="", flush=True)
        query=r.recognize_google(audio,language='en-in')
        print("\r",end="", flush=True)
        print(f"user said: {query}\n")

    except Exception as e:
        print("say that again please sir")
        return "None"
    return query

def call_day():
    day=datetime.datetime.today().weekday()+1
    day_dict={
        1:"Monday",
        2:"Tuesday",
        3:"Wensday",
        4:"Thursday",
        5:"Friday",
        6:"Saturday",
        7:"Sunday"
    }
    if day in day_dict.keys():
        day_of_week=day_dict[day]
        print(day_of_week)
    return day_of_week



def wishMe():
    hour=int(datetime.datetime.now().hour)
    t=time.strftime("%I:%M:%p")
    day=call_day()

    if(hour>=0) and (hour<=12) and ('AM' in t):
        speak(f"Good Morning Boss, it's {day} and the time {t}")
    elif(hour>=12) and (hour<=16) and ('PM' in t):
        speak(f"Good Afternoon Boss, it's {day} and the time {t}")
    else:
        speak(f"Good Evening Boss, it's {day} and the time {t}")


def social_media(command):
    if 'facebook' in command:
        speak("opening your facebook")
        webbrowser.open("https://www.facebook.com/")
    elif 'whatsapp' in command:
        speak("opening your whatsapp")
        webbrowser.open("https://web.whatsapp.com/")
    elif 'instagram' in command:
        speak("opening your instagram")
        webbrowser.open("https://www.instagram.com/")
    elif 'goggle' in command:
        speak("opening your google")
        webbrowser.open("https://www.goggle.com/")
    else:
        speak("No Result Found")

def schedule():
    day=call_day().lower()
    speak("Boss today's Schedule is ")
    week={
    "Monday" : "Boss, today is set weekend goal and try to reach weekend goal",
    "Tuesday" : "Boss, today is Naukari and linked in apps checkout and updates,and also apply new jobs ",
    "Wensday" : "Boss , today is create new project work, and also search some information of about that",
    "Thursday" : "Boss, today is yesterday remaining work complete",
    "Friday" : "Boss , today is go new movie, and boss ala vundhi vachhi naku kuda cheppali boss ",
    "saturday" : "Boss, today is checkout naukari and linkedin apps for job updates",
    "Sunday" : "Boss, today cook a dish of biryani or chicken reciepe and also some give tips you want boss "
    }
    if day in week.keys():
        speak(week[day])

def openApp(command):
    if "calculator" in command:
        speak("opening calculator")
        os.startfile('C:\\Windows\\System32\\calc.exe')
    elif "calculator" in command:
        speak("opening notepad")
        os.startfile('C:\\windows\\System32\\notepad.exe')
    elif "calculator" in command:
        speak("opening paint")
        os.startfile('C:\\Windows\\System32\\mspaint.exe')





if __name__ == "__main__":
    wishMe()
    while True:
        query=input("Enter your Command-> ")
        if('facebook' in query) or ('discord' in query) or ('whatsapp' in query) or ('instagram'in query) or ('google' in query):
            social_media(query)
        elif("timetable" in query) or ("schedule" in query):
            schedule()
        elif("volume up" in query) or ("increase volume" in query):
            pyautogui.press("volume up")
            speak("volume increased")
        elif("volume down " in query) or ("decrease volume" in query):
            pyautogui.press("volume down")
            speak("volume decrease")
        elif("volume mute" in query) or ("mute the sound" in query):
            pyautogui.press("volume muted")
            speak("volume Muted")
        elif("open calulator" in query) or ("open notepad" in query) or ("open paint" in query) or ("open whatsApp Beta" in query):
            openApp(query)
        elif "exit" in query:
            sys.exit()

             
       
 
# speak("Hello, I'm Maheswar")


